package com.example.appathon.util


object PermissionUtil {
    // Your utility code for handling permissions goes here
}