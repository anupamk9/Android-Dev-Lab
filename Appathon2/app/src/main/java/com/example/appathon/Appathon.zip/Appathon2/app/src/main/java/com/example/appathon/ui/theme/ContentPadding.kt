package com.example.appathon.ui.theme

// ui/theme/ContentPadding.kt

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.ui.unit.dp

val ContentPadding = PaddingValues(Dimens.SpaceLarge)
